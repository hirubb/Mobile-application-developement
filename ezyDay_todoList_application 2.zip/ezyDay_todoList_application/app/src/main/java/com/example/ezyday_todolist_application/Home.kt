package com.example.ezyday_todolist_application


import Task
import TaskAdapter
import android.app.AlarmManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.widget.Button
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.google.gson.Gson
import com.google.gson.reflect.TypeToken
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale


class Home : AppCompatActivity(), TaskInputFragment.TaskInputListener {

    private lateinit var taskAdapter: TaskAdapter
    private lateinit var taskList: MutableList<Task>
    private val sharedPreferences by lazy {
        getSharedPreferences(
            "task_prefs",
            Context.MODE_PRIVATE
        )
    }
    private val gson by lazy { Gson() }


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_home)


        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main)) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }

        taskList = loadTasksFromPreferences()

        val recyclerView: RecyclerView = findViewById(R.id.recyclerView)
        recyclerView.layoutManager = LinearLayoutManager(this)
//        taskAdapter = TaskAdapter(taskList, supportFragmentManager) { saveTasksToPreferences() }
//        recyclerView.adapter = taskAdapter

        val addReminderButton: Button = findViewById(R.id.addReminderButton)
        addReminderButton.setOnClickListener {
            val taskInputFragment = TaskInputFragment()
            taskInputFragment.show(supportFragmentManager, "TaskInputFragment")
        }
    }

    override fun onTaskInput(taskName: String, taskTime: String) {
        taskList.add(Task(taskName, taskTime, false))
        taskAdapter.notifyItemInserted(taskList.size - 1)
        saveTasksToPreferences()  // Save the updated task list


        // Schedule the notification
        scheduleNotification(taskName, taskTime)


    }

    private fun scheduleNotification(taskName: String, taskTime: String) {
        val dateFormat = SimpleDateFormat("yyyy-MM-dd HH:mm", Locale.getDefault())
        val taskDate: Date = try {
            dateFormat.parse(taskTime) ?: return
        } catch (e: Exception) {
            e.printStackTrace()
            return
        }
        val alarmManager = getSystemService(Context.ALARM_SERVICE) as AlarmManager
        val intent = Intent(this, TaskReminderReceiver::class.java).apply {
            putExtra("task_title", taskName)
            putExtra("task_time", taskTime)
            putExtra("notification_id", taskList.size) // Use unique ID
        }
        val pendingIntent = PendingIntent.getBroadcast(
            this,
            taskList.size,
            intent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE // Adding FLAG_IMMUTABLE for compatibility
        )
        alarmManager.setExact(AlarmManager.RTC_WAKEUP, taskDate.time, pendingIntent)
    }

    fun canScheduleExactAlarms(context: Context): Boolean {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            val alarmManager = context.getSystemService(ALARM_SERVICE) as AlarmManager
            return alarmManager.canScheduleExactAlarms()
        }
        return true // Exact alarms are allowed on devices below Android 12
    }

    fun requestExactAlarmPermission(context: Context) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            val intent: Intent = Intent(Settings.ACTION_REQUEST_SCHEDULE_EXACT_ALARM)
            context.startActivity(intent)
        }
    }

    fun setExactAlarm(context: Context, triggerAtMillis: Long) {
        val alarmManager = context.getSystemService(ALARM_SERVICE) as AlarmManager
        val intent = Intent(context, TaskReminderReceiver::class.java)
        val pendingIntent = PendingIntent.getBroadcast(context, 0, intent, 0)

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            if (canScheduleExactAlarms(context)) {
                alarmManager.setExact(AlarmManager.RTC_WAKEUP, triggerAtMillis, pendingIntent)
            } else {
                requestExactAlarmPermission(context)
            }
        } else {
            alarmManager.setExact(AlarmManager.RTC_WAKEUP, triggerAtMillis, pendingIntent)
        }
    }


    private fun saveTasksToPreferences() {
        val taskListJson = gson.toJson(taskList)
        sharedPreferences.edit().putString("task_list", taskListJson).apply()
    }

    private fun loadTasksFromPreferences(): MutableList<Task> {
        val taskListJson = sharedPreferences.getString("task_list", null)
        if (taskListJson != null) {
            val taskListType = object : TypeToken<MutableList<Task>>() {}.type
            return gson.fromJson(taskListJson, taskListType)
        }
        return mutableListOf()  // Return an empty list if no tasks are saved
    }


}
