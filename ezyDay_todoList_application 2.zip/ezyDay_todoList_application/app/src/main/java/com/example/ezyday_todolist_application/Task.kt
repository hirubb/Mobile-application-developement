data class Task(
    var title: String,
    var time: String,
    var isCompleted: Boolean,
    var isTimerRunning: Boolean = false,
    var elapsedTimeMillis: Long = 0
)
