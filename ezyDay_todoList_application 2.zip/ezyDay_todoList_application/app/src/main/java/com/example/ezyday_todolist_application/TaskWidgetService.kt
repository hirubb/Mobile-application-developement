package com.example.ezyday_todolist_application

import Task
import android.content.Context
import android.content.Intent
import android.widget.RemoteViews
import android.widget.RemoteViewsService
import com.example.ezyday_todolist_application.R

import com.google.gson.Gson
import com.google.gson.reflect.TypeToken

class TaskWidgetService : RemoteViewsService() {
    override fun onGetViewFactory(intent: Intent?): RemoteViewsFactory {
        return TaskRemoteViewsFactory(applicationContext)
    }
}

class TaskRemoteViewsFactory(private val context: Context) : RemoteViewsService.RemoteViewsFactory {
    private var taskList: List<Task> = emptyList()

    override fun onCreate() {
        // Load tasks from SharedPreferences
        val sharedPreferences = context.getSharedPreferences("task_prefs", Context.MODE_PRIVATE)
        val taskListJson = sharedPreferences.getString("task_list", null)
        if (taskListJson != null) {
            val taskListType = object : TypeToken<List<Task>>() {}.type
            taskList = Gson().fromJson(taskListJson, taskListType)
        }
    }

    override fun onDataSetChanged() {
        // Called when the widget is updated
    }

    override fun onDestroy() {
        taskList = emptyList()
    }

    override fun getCount(): Int = taskList.size

    override fun getViewAt(position: Int): RemoteViews {
        val task = taskList[position]
        val views = RemoteViews(context.packageName, R.layout.widget_task_item)
        views.setTextViewText(R.id.widgetTaskTitle, task.title)
        views.setTextViewText(R.id.widgetTaskTime, task.time)
        return views
    }

    override fun getLoadingView(): RemoteViews? = null
    override fun getViewTypeCount(): Int = 1
    override fun getItemId(position: Int): Long = position.toLong()
    override fun hasStableIds(): Boolean = true
}
