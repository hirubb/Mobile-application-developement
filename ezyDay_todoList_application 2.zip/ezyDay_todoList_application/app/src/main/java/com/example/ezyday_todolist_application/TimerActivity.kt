package com.example.ezyday_todolist_application

import android.os.Bundle
import android.os.CountDownTimer
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity

class TimerActivity : AppCompatActivity() {
    private lateinit var countdownText: TextView
    private var timer: CountDownTimer? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_timer)

        countdownText = findViewById(R.id.countdownText)

        // Get task time from intent extras
        val taskTime = intent.getStringExtra("task_time") ?: "00:00:00"
        startTimer(taskTime)
    }

    private fun startTimer(taskTime: String) {
        // Convert task time to milliseconds (you may need to adjust this logic)
        val totalTimeInMillis = convertTimeToMillis(taskTime)

        timer = object : CountDownTimer(totalTimeInMillis, 1000) {
            override fun onTick(millisUntilFinished: Long) {
                countdownText.text = formatTime(millisUntilFinished)
            }

            override fun onFinish() {
                countdownText.text = "Time's up!"
            }
        }.start()
    }

    private fun convertTimeToMillis(taskTime: String): Long {
        // Implement your conversion logic here
        // Example: parsing "HH:mm:ss" format
        val parts = taskTime.split(":").map { it.toLong() }
        return (parts[0] * 3600 + parts[1] * 60 + parts[2]) * 1000
    }

    private fun formatTime(millis: Long): String {
        val seconds = (millis / 1000) % 60
        val minutes = (millis / (1000 * 60)) % 60
        val hours = (millis / (1000 * 60 * 60)) % 24
        return String.format("%02d:%02d:%02d", hours, minutes, seconds)
    }

    override fun onDestroy() {
        super.onDestroy()
        timer?.cancel()
    }
}
