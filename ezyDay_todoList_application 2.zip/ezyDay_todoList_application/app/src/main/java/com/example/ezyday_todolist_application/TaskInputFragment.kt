package com.example.ezyday_todolist_application

import android.app.DatePickerDialog
import android.app.Dialog
import android.app.TimePickerDialog
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.EditText
import androidx.fragment.app.DialogFragment
import java.util.*

class TaskInputFragment : DialogFragment() {

    interface TaskInputListener {
        fun onTaskInput(taskName: String, taskDateTime: String)
    }

    override fun onCreateDialog(savedInstanceState: Bundle?): Dialog {
        return super.onCreateDialog(savedInstanceState).apply {
            setTitle("Add New Task")
        }
    }

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        val view = inflater.inflate(R.layout.fragment_task_input, container, false)

        val taskNameInput: EditText = view.findViewById(R.id.taskNameInput)
        val taskDateTimeInput: EditText = view.findViewById(R.id.taskDateTimeInput)
        val saveButton: Button = view.findViewById(R.id.saveButton)

        // Show DatePickerDialog when the date-time input field is clicked
        taskDateTimeInput.setOnClickListener {
            showDatePickerDialog()
        }

        saveButton.setOnClickListener {
            val taskName = taskNameInput.text.toString()
            val taskDateTime = taskDateTimeInput.text.toString()
            (activity as? TaskInputListener)?.onTaskInput(taskName, taskDateTime)
            dismiss()
        }

        return view
    }

    private fun showDatePickerDialog() {
        val calendar = Calendar.getInstance()
        val year = calendar.get(Calendar.YEAR)
        val month = calendar.get(Calendar.MONTH)
        val day = calendar.get(Calendar.DAY_OF_MONTH)

        DatePickerDialog(
            requireContext(),
            { _, selectedYear, selectedMonth, selectedDay ->
                // Show TimePickerDialog after the date is selected
                showTimePickerDialog(selectedYear, selectedMonth, selectedDay)
            },
            year,
            month,
            day
        ).show()
    }

    private fun showTimePickerDialog(year: Int, month: Int, day: Int) {
        val calendar = Calendar.getInstance()
        val hour = calendar.get(Calendar.HOUR_OF_DAY)
        val minute = calendar.get(Calendar.MINUTE)

        TimePickerDialog(
            requireContext(),
            { _, selectedHour, selectedMinute ->
                // Format date and time, and set it to the EditText
                val dateTimeString = String.format(
                    "%d-%02d-%02d %02d:%02d",
                    year,
                    month + 1, // Months are 0-based
                    day,
                    selectedHour,
                    selectedMinute
                )
                view?.findViewById<EditText>(R.id.taskDateTimeInput)?.setText(dateTimeString)
            },
            hour,
            minute,
            true
        ).show()
    }
}
