import android.app.DatePickerDialog
import android.app.TimePickerDialog
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.TextView
import androidx.fragment.app.DialogFragment
import com.example.ezyday_todolist_application.R

import java.text.SimpleDateFormat
import java.util.*

class TaskEditFragment : DialogFragment() {

    private lateinit var task: Task
    private var listener: TaskEditListener? = null

    interface TaskEditListener {
        fun onTaskEdited(task: Task)
    }

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        return inflater.inflate(R.layout.fragment_task_edit, container, false)
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        val editTitle: TextView = view.findViewById(R.id.editTaskTitle)
        val editDateTime: TextView = view.findViewById(R.id.editTaskDateTime)
        val saveButton: Button = view.findViewById(R.id.saveButton)
        val cancelButton: Button = view.findViewById(R.id.cancelButton)

        // Initialize with current task details
        editTitle.text = task.title
        editDateTime.text = task.time

        // Date and Time Picker
        editDateTime.setOnClickListener {
            val calendar = Calendar.getInstance()
            val year = calendar.get(Calendar.YEAR)
            val month = calendar.get(Calendar.MONTH)
            val day = calendar.get(Calendar.DAY_OF_MONTH)
            val hour = calendar.get(Calendar.HOUR_OF_DAY)
            val minute = calendar.get(Calendar.MINUTE)

            DatePickerDialog(requireContext(), { _, selectedYear, selectedMonth, selectedDay ->
                TimePickerDialog(requireContext(), { _, selectedHour, selectedMinute ->
                    val date = String.format("%02d/%02d/%d", selectedDay, selectedMonth + 1, selectedYear)
                    val time = String.format("%02d:%02d", selectedHour, selectedMinute)
                    editDateTime.text = "$date $time"
                }, hour, minute, true).show()
            }, year, month, day).show()
        }

        saveButton.setOnClickListener {
            task.title = editTitle.text.toString()
            task.time = editDateTime.text.toString()
            listener?.onTaskEdited(task)
            dismiss()
        }

        cancelButton.setOnClickListener {
            dismiss()
        }
    }

    fun setTask(task: Task) {
        this.task = task
    }

    fun setTaskEditListener(listener: TaskEditListener) {
        this.listener = listener
    }
}
