import android.annotation.SuppressLint
import android.os.CountDownTimer
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.CheckBox
import android.widget.ImageView
import android.widget.TextView
import androidx.fragment.app.FragmentManager
import androidx.recyclerview.widget.RecyclerView
import com.example.ezyday_todolist_application.R


class TaskAdapter(
    private val taskList: MutableList<Task>,
    private val fragmentManager: FragmentManager,
    private val saveTasks: () -> Unit,
    private val onTaskClick: (Task) -> Unit // Add click listener

) : RecyclerView.Adapter<TaskAdapter.TaskViewHolder>() {


    private var timer: CountDownTimer? = null //new

    class TaskViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        val checkBox: CheckBox = itemView.findViewById(R.id.checkBox)
        val taskTitle: TextView = itemView.findViewById(R.id.taskTitle)
        val taskTime: TextView = itemView.findViewById(R.id.taskTime)
        val editIcon: ImageView = itemView.findViewById(R.id.editIcon)

        fun bind(task: Task) {
            taskTitle.text = task.title // Set the title of the task
            taskTime.text = task.time
            // You can set other properties similarly
        }
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): TaskViewHolder {
        val view = LayoutInflater.from(parent.context)
            .inflate(R.layout.list_item, parent, false)
        return TaskViewHolder(view)
    }

    override fun onBindViewHolder(holder: TaskViewHolder, @SuppressLint("RecyclerView") position: Int) {
        val task = taskList[position]
        holder.bind(task)
        holder.taskTitle.text = task.title
        holder.taskTime.text = task.time
        holder.checkBox.isChecked = task.isCompleted

        holder.itemView.setOnClickListener {
            onTaskClick(task) // Trigger the click listener
        }


        holder.taskTitle.setOnClickListener {
            if (task.isTimerRunning) {
                stopTimer()
                task.isTimerRunning = false
                saveTasks() // Save the updated task list
            } else {
                startTimerForTask(task, holder)
            }


            // Handle UI updates based on task's timer state
            if (task.isTimerRunning) {
                holder.taskTime.text = formatTime(task.elapsedTimeMillis)
            } else {
                holder.taskTime.text = task.time
            }
        }


        holder.editIcon.setOnClickListener {
            val editFragment = TaskEditFragment()
            editFragment.setTask(task)
            editFragment.setTaskEditListener(object : TaskEditFragment.TaskEditListener {
                override fun onTaskEdited(updatedTask: Task) {
                    taskList[position] = updatedTask
                    notifyItemChanged(position)
                }
            })
            editFragment.show(fragmentManager, "TaskEditFragment")
        }

        holder.checkBox.setOnCheckedChangeListener { _, isChecked ->
            task.isCompleted = isChecked
            if (isChecked) {
                // Remove completed task from list
                taskList.removeAt(position)
                notifyItemRemoved(position)
                notifyItemRangeChanged(position, taskList.size)
                saveTasks()  // Save the updated task list after deletion
            }
        }
    }

    private fun startTimerForTask(task: Task, holder: TaskViewHolder) {
        stopTimer() // Stop any ongoing timer

        timer = object : CountDownTimer(Long.MAX_VALUE, 1000) {
            override fun onTick(millisUntilFinished: Long) {
                task.elapsedTimeMillis += 1000
                holder.taskTime.text = formatTime(task.elapsedTimeMillis)
                saveTasks() // Save the updated task list periodically
            }

            override fun onFinish() {
                // Handle timer finish if needed
            }
        }

        task.isTimerRunning = true
        timer?.start()
    }

    private fun stopTimer() {
        timer?.cancel()
        timer = null
        // Reset all task timer states if needed
        taskList.forEach { it.isTimerRunning = false }
        notifyDataSetChanged()
    }

    private fun formatTime(elapsedTimeMillis: Long): String {
        // Convert milliseconds to desired format (hh:mm:ss)
        val seconds = elapsedTimeMillis / 1000
        val hours = seconds / 3600
        val minutes = (seconds % 3600) / 60
        val secs = seconds % 60
        return String.format("%02d:%02d:%02d", hours, minutes, secs)
    }

    override fun getItemCount(): Int {
        return taskList.size
    }
}
